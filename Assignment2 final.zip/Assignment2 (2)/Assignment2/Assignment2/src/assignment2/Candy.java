/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

/**
 *
 * @author Julia Ozaniakova
 */
public class Candy implements Cloneable{
    
    //--------------------------------------------------------------------------
    //PROPERTIES
    //--------------------------------------------------------------------------
    private double price = 0.00;
    private String name = "";
    
    //--------------------------------------------------------------------------
    //CONSTRUCTORS
    //--------------------------------------------------------------------------
    public Candy() {
    }
    
    public Candy(String n, double p) {
        price = p;
        name = n;
    }
    
    public double getPrice() {return price;}
    public void setPrice(double Price) {
        this.price = price;
    }
    
    public String getName() {return name;}
    public void setName(String name) {
        this.name = name;
    }
}
    
