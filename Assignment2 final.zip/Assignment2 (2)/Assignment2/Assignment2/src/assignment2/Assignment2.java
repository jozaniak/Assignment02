/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;
import java.util.*;
/**
 *
 * @author Julia Ozaniakova
 */
public class Assignment2 {

    
    
    
    public static void main(String[] args) { 
        
        //the machine is filled with these candies
        Candy Skittles = new Candy("Skittles", 4.20);
        
        Candy Snickers = new Candy("Snickers", 1.42);
        
        Candy MM = new Candy("M&M", 4.42);
        
        // this is where I created teh actual Candy Machine
        CandyVendingMachine Machine = new CandyVendingMachine(Skittles, 5, Snickers, 2, MM, 1);
        
        //Does the user want to use the Candy machine?
        System.out.println("Welcome! This is the Candy Machine. Would you like some candy? Say C for candy, Q for Quit.");
        Scanner scan = new Scanner(System.in);
        String response = scan.next();
        
        if (response.equalsIgnoreCase("C")) {
            //display the content of the machine
            System.out.println(Machine.DisplayContents()); 
            
            //user chooses a product 
            //user chooses either "1", "2", or "3"
            String choice = scan.next();
            //display the price of the chosen item
            System.out.println("Enter payment amount:$ " + Machine.GetItemPrice(choice));
            double paidAmount = scan.nextDouble();          
            //did the user give me enough money?
            if (paidAmount >= Machine.GetItemPrice(choice)) {
               
            //vend candy
            //if the user gave us enough or more money, he or she will get the candy and their change (if there's any)    
                System.out.println("Here's your " + Machine.VendItem(choice).getName() + " for $" + Machine.GetItemPrice(choice) + ". " + " Here's your change $" + (paidAmount - Machine.GetItemPrice(choice)));
                
            //displays the remaining contents of the machine  
                System.out.println("This is what's left in the machine " + Machine.DisplayContents());
            } else {
            //if the user didn't give us enough money, the machine will ask him or her to give it more
                System.out.println("You didn't pay the whole amount for the candy! Give me at least $" + (Machine.GetItemPrice(choice) - paidAmount) );
               double payMore = scan.nextDouble();
               
               //did the user give us enough? 
               if ((Machine.GetItemPrice(choice) - paidAmount) <= payMore){
                   
                   double amtLeft = Machine.GetItemPrice(choice) - paidAmount;
                //   if the user gave us enough or more money, he or she will get the candy and their change (if there's any)
                    System.out.println("Here's your " + Machine.VendItem(choice).getName() + " for $" + Machine.GetItemPrice(choice) + ". " + " Here's your change $" + (payMore - amtLeft));
                //  displays the remaining contents of the machine 
                    System.out.println("This is what's left in the machine " + Machine.DisplayContents());
                    
                //if the user didn't give the machine enough money again, it will quit           
               }
               else  {
                   System.out.println("You didn't give me enough money again. I'm not going to deal with you anymore. I'll quit now.");
                   System.out.println("This is what's left in the machine " + Machine.DisplayContents());
               }
               
            }  
        }
        else if (response == "Q") {
            return;
        }
        
               
    }          
     
}

