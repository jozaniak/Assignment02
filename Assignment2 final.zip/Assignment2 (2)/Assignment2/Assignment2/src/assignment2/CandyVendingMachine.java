/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
/**
 *
 * @author Julia Ozaniakova
 */
public class CandyVendingMachine implements ICandyVendingMachine{
    Queue<Candy> slot1 = new LinkedList<Candy>();
    Queue<Candy> slot2 = new LinkedList<Candy>();
    Queue<Candy> slot3 = new LinkedList<Candy>();
    
    double balance;
    
    //candy types, and in stock amounts
    
    public CandyVendingMachine (Candy c1, int stock1, Candy c2, int stock2, Candy c3, int stock3) {
        for (int i = 0; i < stock1; i++) {
            slot1.add(c1);
        }
               
        for (int i = 0; i < stock2; i++) {
            slot2.add(c2);
        }
        for (int i = 0; i < stock3; i++) {
            slot3.add(c3);
        }
        
    }
//interface methods
    @Override
    public void TakeMoney(double amount) {
        balance = amount;
         
    }

    @Override
    public void ReturnMoney() {
        System.out.println("Here 's your change: $" + balance);
        balance = 0;
    }

    @Override
    public Candy VendItem(String slotCode) {
        if (slotCode.equals("1")){
            return slot1.remove();
            
            //candy = c1.peek();
        }          
            else if (slotCode.equals("2")) {
            return slot2.remove();}
            
            else if (slotCode.equals("3")) {
            return slot3.remove();}
            else return null;
    }
      
    
    
    @Override
    public String GetMachineInfo() {
        return "This is a Candy Vending Machine";
    }

    @Override
    public String DisplayContents() {
        
        //this is what the machine shows to the user
        //it shows the name, amount,and prize of the candy
        String output = "Here are your options, enter Q to quit:\n";
        output += "Slot 1: " + slot1.peek().getName() + " " + slot1.size() + " $" + slot1.peek().getPrice() + "\n";
        output += "Slot 2: " + slot2.peek().getName() + " " + slot2.size() + " $" + slot2.peek().getPrice() + "\n";
        output += "Slot 3: " + slot3.peek().getName() + " " + slot3.size() + " $" + slot3.peek().getPrice() + "\n";
        return output;
    }
    
    public double GetItemPrice(String choice) {
        if (choice.equals("1")) {
            return slot1.peek().getPrice();
          
        }          
            else if (choice.equals("2")) {
            return slot2.peek().getPrice();
            }
            
            else if (choice.equals("3")) {
            return slot3.peek().getPrice();
            }
            else {    
        System.out.println("This is not valid");
            return 0;
            
            
    }
    }
}
